
function setDisplay(){
    if($('input:radio[id="member_DoubleMajor"]').is(':checked')){
		$('#studentDoubleMajor').show();
	} else{
		$('#studentDoubleMajor').hide();
	}
}

/* 단과대학 선택 시 해당 단과대학의 전공만 선택 가능 */
/* 학생 */
function studentMajorChange(choice_value){
   init_value = new Array(new Array(""), 
      new Array("국어국문학과", "영어영문학과", "중어중문학과", "일어일문학과", "사학과", "문헌정보학과", "아랍지역학과", 
      "미술사학과", "철학과", "문예창작학과"), 
      new Array("행정학과", "경제학과", "정치외교학과", "디지털미디어학과", "아동학과", "청소년지도학과"), 
      new Array("경영정보학과", "국제통상학과", "부동산학과"), 
      new Array("법학과", "법무행정학과"), 
      new Array("융합소프트웨어학부", "디지털콘텐츠디자인학과"), 
      new Array("창의융합인재학부", "사회복지학과", "부동산학과", "법무행정학과", "심리치료학과", "미래융합경영학과", "멀티디자인학과", "계약학과"));
      
   if(choice_value != ""){
      document.ModifyStudent.StudentMajor.options.length = 1;
      loop_count=init_value[choice_value].length;
         
      for(i=0;i<loop_count;i++){
           new_option=document.createElement("OPTION");
           new_option.text=init_value[choice_value][i];
           new_option.value=init_value[choice_value][i];
           document.ModifyStudent.StudentMajor.add(new_option);
       }
      }
      else{
       document.ModifyStudent.StudentMajor.options.length = 1;
      }
}

/* 교수 */
function professorMajorChange(choice_value){
   init_value = new Array(new Array(""), 
      new Array("국어국문학과", "영어영문학과", "중어중문학과", "일어일문학과", "사학과", "문헌정보학과", "아랍지역학과", 
      "미술사학과", "철학과", "문예창작학과"), 
      new Array("행정학과", "경제학과", "정치외교학과", "디지털미디어학과", "아동학과", "청소년지도학과"), 
      new Array("경영정보학과", "국제통상학과", "부동산학과"), 
      new Array("법학과", "법무행정학과"), 
      new Array("융합소프트웨어학부", "디지털콘텐츠디자인학과"), 
      new Array("창의융합인재학부", "사회복지학과", "부동산학과", "법무행정학과", "심리치료학과", "미래융합경영학과", "멀티디자인학과", "계약학과"));
      
   if(choice_value != ""){
      document.ModifyProfessor.ModifyProfessor.options.length = 1;
      loop_count=init_value[choice_value].length;
         
      for(i=0;i<loop_count;i++){
           new_option=document.createElement("OPTION");
           new_option.text=init_value[choice_value][i];
           new_option.value=init_value[choice_value][i];
           document.ModifyProfessor.ModifyProfessor.add(new_option);
       }
      }
      else{
       document.ModifyProfessor.ModifyProfessor.options.length = 1;
      }
}


$(document).ready(function(){

	/* 학생 정보 변경 */
    $('#modifyComplete').click(function(){
        if($('#studentGender option:selected').val()==" "||
        $('#userPhoneNum').val().length==0||
        $('#studentGrade option:selected').val()==" "||
        $('#studentMajor option:selected').val()==" "||
        $('#studentColleges option:selected').val()==" "){
            alert("필수항목을 모두 입력해주세요.");
            return "modifyStudent";

        }
    });

	/* 교수 정보 변경 */
	$('#modifyCompleteP').click(function(){
        if($('#userPhoneNum').val().length==0||
        $('#professorColleges option:selected').val()==" "||
        $('#professorMajor option:selected').val()==" "||
        $('#professorRoom').val().length==0||
        $('#professorRoomNum').val().length==0){
            alert("필수항목을 모두 입력해주세요.");
            return modifyProfessor;

        }
    });
	
	/* 연락처 숫자만 입력 가능 */
	$('#userPhoneNum').keypress(function (event) {
	        if (event.which && (event.which <= 47 || event.which >= 58) && event.which != 8) {
	            event.preventDefault(); 
	        }
	    });
	$("#userPhoneNum").keyup(function(e) { 
		if (!(e.keyCode >=37 && e.keyCode<=40)) {
			var v = $(this).val();
			$(this).val(v.replace(/[^a-z0-9]/gi,''));
		}
	});


	/* 비밀번호 변경 */
	$('#modifyCompletePW').click(function(){
        if($('#userLoginPwd').val().length==0||
        $('#userNewPwd').val().length==0||
        $('#userNewPwdCheck').val().length==0){
            alert("필수항목을 모두 입력해주세요.");
            return false;
        }

	 if($('#userLoginPwd').val().length < 8 ||
        $('#userNewPwd').val().length < 8||
        $('#userNewPwdCheck').val().length < 8){
			alert("비밀번호는 8자보다 많아야합니다.");
			return false;
		}
		
	/* 현재 비밀번호와 새 비밀번호가 갈은 경우 alert */	
	if($('#userLoginPwd').val() == $('#userNewPwd').val()) {
			alert("새 비밀번호가 현재 비밀번호와 일치합니다. 비밀변호를 변경해주세요.");
			return false;
		}	
	
	/* 새 비밀번호가 일치하지 않는 경우 alert */		
	 if($('#userNewPwd').val() != $('#userNewPwdCheck').val()) {
			alert("비밀번호를 다시 확인해주세요.");
			return false;
		}
	
    });
	
	
	/* 취소 버튼 클릭 시 창 닫기 */
	$('#cancelBtn').click(function(){
		window.close();
	});
});

/* 새 비밀번호 다를 경우 text 띄우기 */
function isSame(){
    var password = $('#userNewPwd').val();
    var pwcheck = $('#userNewPwdCheck').val();
    if(password == pwcheck){
    $('#pwValue').text('비밀번호가 일치합니다.').css('color', 'steelblue');
    }else{
     $('#pwValue').text('비밀번호가 일치하지 않습니다.').css('color', 'red');  
    }
}