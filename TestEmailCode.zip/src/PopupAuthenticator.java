import javax.mail.*;
import javax.swing.*;
import java.util.*;

public class PopupAuthenticator
    extends Authenticator {

  public PasswordAuthentication
      getPasswordAuthentication() {
    String username, password;

    String result = JOptionPane.showInputDialog(
      "Enter 'username,password'");

    StringTokenizer st =
      new StringTokenizer(result, ",");
    username = st.nextToken();
    password = st.nextToken();

    return new PasswordAuthentication(
      username, password);
  }
}