
import java.util.*;
import java.io.*;
import javax.mail.*;
//import javax.mail.internet.*;

/**
 * @author Administrator
 *
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class POP3Test {

	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.println("아이디를 입력해주세요");
//		String ID = sc.next();
//		System.out.println("비밀번호를 입력해주세요");
//		String Pwd = sc.next();

		// POP3 주소
		String host = "outlook.office365.com";
		// 이메일아이디
		String username = "lovebus5045@mju.ac.kr";
		// 비밀번호
		String password = "126479dD!@#$";
		// 다운로드된 파일이 저장되는 경우
		String downloadPath = "F:\\mailDown";
		// Create empty properties
		Properties props = new Properties();

		// Get session
		Session session = Session.getDefaultInstance(props, null);

		Store store = null;
		Folder folder = null;
		try {
			// Pop3 서버 가져오기
			store = session.getStore("pop3s");
			store.connect(host, username, password);

			// Get folder
			folder = store.getFolder("INBOX");
			folder.open(Folder.READ_ONLY);

			// 이메일 박스
			Message message[] = folder.getMessages();
			int messageLength = 0;

			// 제목 길이를 가져온다.
			messageLength = message.length;

			// 이메일 제목
			for (int i = 0, n = message.length; i < n; i++) {
				// System.out.println(i + ": " + message[i].getFrom()[0] + "\t" +
				// message[i].getSubject());
			}

			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

			// Get directory
			for (int i = 0, n = message.length; i < n; i++) {
				Address from = message[i].getFrom()[0];
				String subject = message[i].getSubject();
				// 이메일 Stream정보 제공
				// message[i].writeTo(System.out);

				// from = message[i].getFrom()[0];
				subject = message[i].getSubject();
				// 보낸이 = messgae[i].getFrom()[0] + 제목 = message[i].getSubject()
				System.out.println(i + ": " + from + "\t" + subject);
				System.out.println("======================================================");
				// 이메일 내용 읽어오기 message[i].getContent()
				System.out.println(message[i].getContent() + "\n");

				// 첨부파일이 있을 경우 파일에다가 mail을 붙인다.
				POP3Test.appendToFile(downloadPath + "in.mbx", message[i]);
				
			}

			// Close connection
			folder.close(false);
			store.close();

		} catch (Exception e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}

	}

	public static boolean writeToFile(String filename, Message message) {
		boolean isSuccess = false;
		File f = new File(filename);
		boolean isWritable = false;
		isWritable = f.canWrite();
		if (f.exists())// || !isWritable)
			return isSuccess;

		try {
			FileOutputStream fos = new FileOutputStream(f);
			message.writeTo(fos);
			byte[] b = (byte[]) message.getContent();
			fos.write(b);
			fos.close();
			isSuccess = true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return isSuccess;
	}

	public static boolean appendToFile(String filename, Message message) {
		boolean isSuccess = false;

		File f = new File(filename);
		boolean isWritable = false;
		isWritable = f.canWrite();
		if (!f.exists()) {
			try {
				f.createNewFile();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		try {
			FileOutputStream fos = new FileOutputStream(f, true);
			String prefix = "From ???@??? Mon Oct 25 15:51:49 2004\n";

			fos.write(prefix.getBytes());
			message.writeTo(fos);
			fos.close();
			isSuccess = true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return isSuccess;

	}
}
