package com.mju.groupware.constant;

public class ConstantUserFunctionURL {

   private String CMTUrl;
   private String CPUrl;
   private String MPUrl;
   private String CPWUrl;
   private String RWUrl;
   private String ULPWD;
   private String EAUrl;

   public String getEAUrl() {
      return EAUrl;
   }

   public void setEAUrl(String eAUrl) {
      EAUrl = eAUrl;
   }

   public String getULPWD() {
      return ULPWD;
   }

   public void setULPWD(String uLPWD) {
      ULPWD = uLPWD;
   }

   public String getRWUrl() {
      return RWUrl;
   }

   public void setRWUrl(String rWUrl) {
      RWUrl = rWUrl;
   }

   public String getCPWUrl() {
      return CPWUrl;
   }

   public void setCPWUrl(String cPWUrl) {
      CPWUrl = cPWUrl;
   }

   public String getCMTUrl() {
      return CMTUrl;
   }

   public void setCMTUrl(String cMTUrl) {
      CMTUrl = cMTUrl;
   }

   public String getCPUrl() {
      return CPUrl;
   }

   public void setCPUrl(String cPUrl) {
      CPUrl = cPUrl;
   }

   public String getMPUrl() {
      return MPUrl;
   }

   public void setMPUrl(String mPUrl) {
      MPUrl = mPUrl;
   }

}