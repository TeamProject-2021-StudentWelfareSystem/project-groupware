package com.mju.groupware.constant;

public class ConstantDoFindPassword {
   private String UName;
   private String Pwd;
   private String AuthNum;
   private String FPUrl;
   private String SSPUrl;
   private String SRole;
   private String PRole;
   private String RMS;
   private String RMP;
   private String CPUrl;
   private String CPUrl3;
   private String ULPWD;
   private String RMPWD;
   private String UNPWD;
   private String UNPWDC;
   private String MPUrl;

   public String getMPUrl() {
      return MPUrl;
   }

   public void setMPUrl(String mPUrl) {
      MPUrl = mPUrl;
   }

   public String getUNPWDC() {
      return UNPWDC;
   }

   public void setUNPWDC(String uNPWDC) {
      UNPWDC = uNPWDC;
   }

   public String getUNPWD() {
      return UNPWD;
   }

   public void setUNPWD(String uNPWD) {
      UNPWD = uNPWD;
   }

   public String getRMPWD() {
      return RMPWD;
   }

   public void setRMPWD(String rMPWD) {
      RMPWD = rMPWD;
   }

   public String getULPWD() {
      return ULPWD;
   }

   public void setULPWD(String uLPWD) {
      ULPWD = uLPWD;
   }

   public String getCPUrl3() {
      return CPUrl3;
   }

   public void setCPUrl3(String cPUrl3) {
      CPUrl3 = cPUrl3;
   }

   public String getCPUrl() {
      return CPUrl;
   }

   public void setCPUrl(String cPUrl) {
      CPUrl = cPUrl;
   }

   public String getRMS() {
      return RMS;
   }

   public void setRMS(String rMS) {
      RMS = rMS;
   }

   public String getRMP() {
      return RMP;
   }

   public void setRMP(String rMP) {
      RMP = rMP;
   }

   public String getSRole() {
      return SRole;
   }

   public void setSRole(String sRole) {
      SRole = sRole;
   }

   public String getPRole() {
      return PRole;
   }

   public void setPRole(String pRole) {
      PRole = pRole;
   }

   public String getSSPUrl() {
      return SSPUrl;
   }

   public void setSSPUrl(String sSPUrl) {
      SSPUrl = sSPUrl;
   }

   public String getFPUrl() {
      return FPUrl;
   }

   public void setFPUrl(String fPUrl) {
      FPUrl = fPUrl;
   }

   public String getAuthNum() {
      return AuthNum;
   }

   public void setAuthNum(String authNum) {
      AuthNum = authNum;
   }

   public String getPwd() {
      return Pwd;
   }

   public void setPwd(String pwd) {
      Pwd = pwd;
   }

   public String getUName() {
      return UName;
   }

   public void setUName(String uName) {
      UName = uName;
   }

}