package com.mju.groupware.constant;

public class ConstantFindPassword {

   private String FPUrl;
   private String SPUrl;

   public String getSPUrl() {
      return SPUrl;
   }

   public void setSPUrl(String sPUrl) {
      SPUrl = sPUrl;
   }

   public String getFPUrl() {
      return FPUrl;
   }

   public void setFPUrl(String fPUrl) {
      FPUrl = fPUrl;
   }

}