package com.mju.groupware.constant;

public class ConstantAdminStudentDao {
	private String InsertInformation;
	private String UpdateUserID;
	private String GetGrade;
	private String UpdateStudentGender;
	private String UpdateStudentGrade;
	private String UpdateStudentDoubleMajor;
	private String SelectStudentProfileInfo;
	private String SelectMyPageStudentInfo;
	private String NoDoubleMajor;
	private String SelectMyPageStudentInfoByID;
	private String UpdateStudentColleges;
	private String UpdateStudentMajor;
	private String SelectStudentInfo;
	private String InsertWithdrawalStudent;
	private String DeleteWithdrawalStudent;
	private String DeleteWithdrawalStudentList;
	
	public String getUpdateUserID() {
		return UpdateUserID;
	}

	public void setUpdateUserID(String updateUserID) {
		UpdateUserID = updateUserID;
	}

	public String getGetGrade() {
		return GetGrade;
	}

	public void setGetGrade(String getGrade) {
		GetGrade = getGrade;
	}

	public String getUpdateStudentGender() {
		return UpdateStudentGender;
	}

	public void setUpdateStudentGender(String updateStudentGender) {
		UpdateStudentGender = updateStudentGender;
	}

	public String getUpdateStudentGrade() {
		return UpdateStudentGrade;
	}

	public void setUpdateStudentGrade(String updateStudentGrade) {
		UpdateStudentGrade = updateStudentGrade;
	}

	public String getUpdateStudentDoubleMajor() {
		return UpdateStudentDoubleMajor;
	}

	public void setUpdateStudentDoubleMajor(String updateStudentDoubleMajor) {
		UpdateStudentDoubleMajor = updateStudentDoubleMajor;
	}

	public String getSelectStudentProfileInfo() {
		return SelectStudentProfileInfo;
	}

	public void setSelectStudentProfileInfo(String selectStudentProfileInfo) {
		SelectStudentProfileInfo = selectStudentProfileInfo;
	}

	public String getSelectMyPageStudentInfo() {
		return SelectMyPageStudentInfo;
	}

	public void setSelectMyPageStudentInfo(String selectMyPageStudentInfo) {
		SelectMyPageStudentInfo = selectMyPageStudentInfo;
	}

	public String getNoDoubleMajor() {
		return NoDoubleMajor;
	}

	public void setNoDoubleMajor(String noDoubleMajor) {
		NoDoubleMajor = noDoubleMajor;
	}

	public String getSelectMyPageStudentInfoByID() {
		return SelectMyPageStudentInfoByID;
	}

	public void setSelectMyPageStudentInfoByID(String selectMyPageStudentInfoByID) {
		SelectMyPageStudentInfoByID = selectMyPageStudentInfoByID;
	}

	public String getUpdateStudentColleges() {
		return UpdateStudentColleges;
	}

	public void setUpdateStudentColleges(String updateStudentColleges) {
		UpdateStudentColleges = updateStudentColleges;
	}

	public String getUpdateStudentMajor() {
		return UpdateStudentMajor;
	}

	public void setUpdateStudentMajor(String updateStudentMajor) {
		UpdateStudentMajor = updateStudentMajor;
	}

	public String getSelectStudentInfo() {
		return SelectStudentInfo;
	}

	public void setSelectStudentInfo(String selectStudentInfo) {
		SelectStudentInfo = selectStudentInfo;
	}

	public String getInsertWithdrawalStudent() {
		return InsertWithdrawalStudent;
	}

	public void setInsertWithdrawalStudent(String insertWithdrawalStudent) {
		InsertWithdrawalStudent = insertWithdrawalStudent;
	}

	public String getDeleteWithdrawalStudent() {
		return DeleteWithdrawalStudent;
	}

	public void setDeleteWithdrawalStudent(String deleteWithdrawalStudent) {
		DeleteWithdrawalStudent = deleteWithdrawalStudent;
	}

	public String getDeleteWithdrawalStudentList() {
		return DeleteWithdrawalStudentList;
	}

	public void setDeleteWithdrawalStudentList(String deleteWithdrawalStudentList) {
		DeleteWithdrawalStudentList = deleteWithdrawalStudentList;
	}

	public String getInsertInformation() {
		return InsertInformation;
	}

	public void setInsertInformation(String insertInformation) {
		InsertInformation = insertInformation;
	}
	
}
