package com.mju.groupware.constant;

public class ConstantHome {

   private String SRole;
   private String ARole;
   private String PRole;
   private String DFormat;
   private String NL;
   private String CL;
   private String HUrl;
   private String MPSUrl;
   private String MPPUrl;
   private String RUrl;
   
   public String getMPSUrl() {
      return MPSUrl;
   }

   public void setMPSUrl(String mPSUrl) {
      MPSUrl = mPSUrl;
   }

   public String getMPPUrl() {
      return MPPUrl;
   }

   public void setMPPUrl(String mPPUrl) {
      MPPUrl = mPPUrl;
   }

   public String getRUrl() {
      return RUrl;
   }

   public void setRUrl(String rUrl) {
      RUrl = rUrl;
   }

   public String getHUrl() {
      return HUrl;
   }

   public void setHUrl(String hUrl) {
      HUrl = hUrl;
   }

   public String getCL() {
      return CL;
   }

   public void setCL(String cL) {
      CL = cL;
   }

   public String getNL() {
      return NL;
   }

   public void setNL(String nL) {
      NL = nL;
   }

   public String getDFormat() {
      return DFormat;
   }

   public void setDFormat(String dFormat) {
      DFormat = dFormat;
   }

   public String getSRole() {
      return SRole;
   }

   public String getARole() {
      return ARole;
   }

   public void setARole(String aRole) {
      ARole = aRole;
   }

   public String getPRole() {
      return PRole;
   }

   public void setPRole(String pRole) {
      PRole = pRole;
   }

   public void setSRole(String sRole) {
      SRole = sRole;
   }

}