package com.mju.groupware.constant;

public class ConstantAdminStudentController {
	private String UserName;
	private String UserLoginID;
	private String UserPhoneNum;
	private String UserPhone;
	private String UserEmail;
	private String Email;
	private String UserGrade;
	private String Grade;
	private String UserMajor;
	private String UserNameForOpen;
	
	private String RSignupStudent;
	private String RModifyStudent;
	private String RMyPageStudent;

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getGrade() {
		return Grade;
	}

	public void setGrade(String grade) {
		Grade = grade;
	}

	public String getRSignupStudent() {
		return RSignupStudent;
	}

	public void setRSignupStudent(String rSignupStudent) {
		RSignupStudent = rSignupStudent;
	}

	public String getRModifyStudent() {
		return RModifyStudent;
	}

	public void setRModifyStudent(String rModifyStudent) {
		RModifyStudent = rModifyStudent;
	}

	public String getRMyPageStudent() {
		return RMyPageStudent;
	}

	public void setRMyPageStudent(String rMyPageStudent) {
		RMyPageStudent = rMyPageStudent;
	}

	public String getUserNameForOpen() {
		return UserNameForOpen;
	}

	public void setUserNameForOpen(String userNameForOpen) {
		UserNameForOpen = userNameForOpen;
	}

	public String getUserEmail() {
		return UserEmail;
	}

	public void setUserEmail(String userEmail) {
		UserEmail = userEmail;
	}

	public String getUserGrade() {
		return UserGrade;
	}

	public void setUserGrade(String userGrade) {
		UserGrade = userGrade;
	}

	public String getUserMajor() {
		return UserMajor;
	}

	public void setUserMajor(String userMajor) {
		UserMajor = userMajor;
	}

	public String getUserPhone() {
		return UserPhone;
	}

	public void setUserPhone(String userPhone) {
		UserPhone = userPhone;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getUserLoginID() {
		return UserLoginID;
	}

	public void setUserLoginID(String userLoginID) {
		UserLoginID = userLoginID;
	}

	public String getUserPhoneNum() {
		return UserPhoneNum;
	}

	public void setUserPhoneNum(String userPhoneNum) {
		UserPhoneNum = userPhoneNum;
	}

}