package com.mju.groupware.constant;

public class ConstantDoSignUp {
   private String Pwd;
   private String PhoneNum;
   private String SNum;
   private String SName;
   private String SRole;
   private String PNum;
   private String PName;
   private String PRole;
   private String SSUrl;
   private String SLUrl;

   
   public String getSLUrl() {
      return SLUrl;
   }

   public void setSLUrl(String sLUrl) {
      SLUrl = sLUrl;
   }

   public String getSSUrl() {
      return SSUrl;
   }

   public void setSSUrl(String sSUrl) {
      SSUrl = sSUrl;
   }

   public String getSRole() {
      return SRole;
   }

   public void setSRole(String sRole) {
      SRole = sRole;
   }

   public String getSName() {
      return SName;
   }

   public void setSName(String sName) {
      SName = sName;
   }

   public String getSNum() {
      return SNum;
   }

   public void setSNum(String sNum) {
      SNum = sNum;
   }

   public String getPNum() {
      return PNum;
   }

   public void setPNum(String pNum) {
      PNum = pNum;
   }

   public String getPName() {
      return PName;
   }

   public void setPName(String pName) {
      PName = pName;
   }

   public String getPRole() {
      return PRole;
   }

   public void setPRole(String pRole) {
      PRole = pRole;
   }

   public String getPhoneNum() {
      return PhoneNum;
   }

   public void setPhoneNum(String phoneNum) {
      PhoneNum = phoneNum;
   }

   public String getPwd() {
      return Pwd;
   }

   public void setPwd(String pwd) {
      Pwd = pwd;
   }

}