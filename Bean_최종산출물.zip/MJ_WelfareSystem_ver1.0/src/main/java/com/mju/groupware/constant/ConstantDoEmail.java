package com.mju.groupware.constant;

public class ConstantDoEmail {
   private String EmailAdress;
   private String DateFormat;
   private String AuthUrl;
   private String AgreeUrl;
   private String AuthNum;
   private String EPwd;
   private String EC;
   private String EV;
   private String BA;
   private String EM;
   private String RELURL;
   private String REURL;
   private String EURL;
   private String ECURL;

   public String getECURL() {
      return ECURL;
   }

   public void setECURL(String eCURL) {
      ECURL = eCURL;
   }

   public String getEURL() {
      return EURL;
   }

   public void setEURL(String eURL) {
      EURL = eURL;
   }

   public String getRELURL() {
      return RELURL;
   }

   public void setRELURL(String rELURL) {
      RELURL = rELURL;
   }

   public String getREURL() {
      return REURL;
   }

   public void setREURL(String rEURL) {
      REURL = rEURL;
   }

   public String getEM() {
      return EM;
   }

   public void setEM(String eM) {
      EM = eM;
   }

   public String getBA() {
      return BA;
   }

   public void setBA(String bA) {
      BA = bA;
   }

   public String getEV() {
      return EV;
   }

   public void setEV(String eV) {
      EV = eV;
   }

   public String getEC() {
      return EC;
   }

   public void setEC(String eC) {
      EC = eC;
   }

   public String getEPwd() {
      return EPwd;
   }

   public void setEPwd(String ePwd) {
      EPwd = ePwd;
   }

   public String getAuthNum() {
      return AuthNum;
   }

   public void setAuthNum(String authNum) {
      AuthNum = authNum;
   }

   public String getEmailAdress() {
      return EmailAdress;
   }

   public void setEmailAdress(String emailAdress) {
      EmailAdress = emailAdress;
   }

   public String getAgreeUrl() {
      return AgreeUrl;
   }

   public void setAgreeUrl(String agreeUrl) {
      AgreeUrl = agreeUrl;
   }

   public String getAuthUrl() {
      return AuthUrl;
   }

   public void setAuthUrl(String authUrl) {
      AuthUrl = authUrl;
   }

   public String getDateFormat() {
      return DateFormat;
   }

   public void setDateFormat(String dateFormat) {
      DateFormat = dateFormat;
   }

}