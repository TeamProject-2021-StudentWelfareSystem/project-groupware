package com.mju.groupware.constant;

public class ConstantEmail {

   private String EMURL;

   public String getEMURL() {
      return EMURL;
   }

   public void setEMURL(String eMURL) {
      EMURL = eMURL;
   }

   

}