package com.mju.groupware.dto;

public class MergeTeam {

	private String TeamID;
	private String ClassName;
	private String ClassProfessorName;
	private String TeamName;

	public String getTeamID() {
		return TeamID;
	}

	public void setTeamID(String teamID) {
		TeamID = teamID;
	}

	public String getClassName() {
		return ClassName;
	}

	public void setClassName(String className) {
		ClassName = className;
	}

	public String getClassProfessorName() {
		return ClassProfessorName;
	}

	public void setClassProfessorName(String classProfessorName) {
		ClassProfessorName = classProfessorName;
	}

	public String getTeamName() {
		return TeamName;
	}

	public void setTeamName(String teamName) {
		TeamName = teamName;
	}

}
