package com.mju.groupware.constant;

public class ConstantMyInquiryList {
   private String MIList;
   private String MIUrl;

   public String getMIList() {
      return MIList;
   }

   public void setMIList(String mIList) {
      MIList = mIList;
   }

   public String getMIUrl() {
      return MIUrl;
   }

   public void setMIUrl(String mIUrl) {
      MIUrl = mIUrl;
   }

}