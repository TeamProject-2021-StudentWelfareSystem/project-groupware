package com.mju.groupware.constant;

public class ConstantMyPostList {

   private String MBList;
   private String MBUrl;
   public String getMBList() {
      return MBList;
   }
   public void setMBList(String mBList) {
      MBList = mBList;
   }
   public String getMBUrl() {
      return MBUrl;
   }
   public void setMBUrl(String mBUrl) {
      MBUrl = mBUrl;
   }
   
   
}