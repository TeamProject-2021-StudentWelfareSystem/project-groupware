package com.mju.groupware.constant;

public class ConstantAdminProfessorController {
	private String UserName;
	private String UserLoginID;
	private String UserPhoneNum;
	private String UserPhone;
	private String UserEmail;
	private String UserMajor;
	private String UserNameForOpen;
	private String Email;
	
	private String RSignupProfessor;
	private String RMyPageProfessor;
	private String RModifyProfessor;
	
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getRSignupProfessor() {
		return RSignupProfessor;
	}
	public void setRSignupProfessor(String rSignupProfessor) {
		RSignupProfessor = rSignupProfessor;
	}
	public String getRMyPageProfessor() {
		return RMyPageProfessor;
	}
	public void setRMyPageProfessor(String rMyPageProfessor) {
		RMyPageProfessor = rMyPageProfessor;
	}
	public String getRModifyProfessor() {
		return RModifyProfessor;
	}
	public void setRModifyProfessor(String rModifyProfessor) {
		RModifyProfessor = rModifyProfessor;
	}
	public String getUserPhone() {
		return UserPhone;
	}
	public void setUserPhone(String userPhone) {
		UserPhone = userPhone;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserLoginID() {
		return UserLoginID;
	}
	public void setUserLoginID(String userLoginID) {
		UserLoginID = userLoginID;
	}
	public String getUserPhoneNum() {
		return UserPhoneNum;
	}
	public void setUserPhoneNum(String userPhoneNum) {
		UserPhoneNum = userPhoneNum;
	}
	public String getUserEmail() {
		return UserEmail;
	}
	public void setUserEmail(String userEmail) {
		UserEmail = userEmail;
	}
	public String getUserMajor() {
		return UserMajor;
	}
	public void setUserMajor(String userMajor) {
		UserMajor = userMajor;
	}
	public String getUserNameForOpen() {
		return UserNameForOpen;
	}
	public void setUserNameForOpen(String userNameForOpen) {
		UserNameForOpen = userNameForOpen;
	}

}
