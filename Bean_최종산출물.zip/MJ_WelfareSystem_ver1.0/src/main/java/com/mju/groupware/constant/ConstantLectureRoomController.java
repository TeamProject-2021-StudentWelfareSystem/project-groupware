package com.mju.groupware.constant;

public class ConstantLectureRoomController {
	private String Nine;
	private String Eleven;
	private String Thirteen;
	private String Fifteen;
	private String Seventeen;
	private String Nineteen;
	
	private String RLectureRoomList;
	private String RReservation;
	private String RRLectureRoomList;
	private String RReservationConfirm;
	private String RReservationModify;
	private String RConfirmMyReservation;
	private String RRMyPageStudent;
	private String RRReservation;

	public String getRRReservation() {
		return RRReservation;
	}

	public void setRRReservation(String rRReservation) {
		RRReservation = rRReservation;
	}

	public String getRLectureRoomList() {
		return RLectureRoomList;
	}

	public void setRLectureRoomList(String rLectureRoomList) {
		RLectureRoomList = rLectureRoomList;
	}

	public String getRReservation() {
		return RReservation;
	}

	public void setRReservation(String rReservation) {
		RReservation = rReservation;
	}

	public String getRRLectureRoomList() {
		return RRLectureRoomList;
	}

	public void setRRLectureRoomList(String rRLectureRoomList) {
		RRLectureRoomList = rRLectureRoomList;
	}

	public String getRReservationConfirm() {
		return RReservationConfirm;
	}

	public void setRReservationConfirm(String rReservationConfirm) {
		RReservationConfirm = rReservationConfirm;
	}

	public String getRReservationModify() {
		return RReservationModify;
	}

	public void setRReservationModify(String rReservationModify) {
		RReservationModify = rReservationModify;
	}

	public String getRConfirmMyReservation() {
		return RConfirmMyReservation;
	}

	public void setRConfirmMyReservation(String rConfirmMyReservation) {
		RConfirmMyReservation = rConfirmMyReservation;
	}

	public String getRRMyPageStudent() {
		return RRMyPageStudent;
	}

	public void setRRMyPageStudent(String rRMyPageStudent) {
		RRMyPageStudent = rRMyPageStudent;
	}

	public String getNine() {
		return Nine;
	}

	public void setNine(String nine) {
		Nine = nine;
	}

	public String getEleven() {
		return Eleven;
	}

	public void setEleven(String eleven) {
		Eleven = eleven;
	}

	public String getThirteen() {
		return Thirteen;
	}

	public void setThirteen(String thirteen) {
		Thirteen = thirteen;
	}

	public String getFifteen() {
		return Fifteen;
	}

	public void setFifteen(String fifteen) {
		Fifteen = fifteen;
	}

	public String getSeventeen() {
		return Seventeen;
	}

	public void setSeventeen(String seventeen) {
		Seventeen = seventeen;
	}

	public String getNineteen() {
		return Nineteen;
	}

	public void setNineteen(String nineteen) {
		Nineteen = nineteen;
	}
	
}
