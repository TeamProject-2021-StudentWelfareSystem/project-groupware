package com.mju.groupware.constant;

public class ConstantHomeController {

	private String Home;
	private String Select;
	private String Consent;
	private String Login;
	private String AdminLogin;
	private String Denied;
	
	public String getHome() {
		return Home;
	}
	public void setHome(String home) {
		Home = home;
	}
	public String getSelect() {
		return Select;
	}
	public void setSelect(String select) {
		Select = select;
	}
	public String getConsent() {
		return Consent;
	}
	public void setConsent(String consent) {
		Consent = consent;
	}
	public String getLogin() {
		return Login;
	}
	public void setLogin(String login) {
		Login = login;
	}
	public String getAdminLogin() {
		return AdminLogin;
	}
	public void setAdminLogin(String adminLogin) {
		AdminLogin = adminLogin;
	}
	public String getDenied() {
		return Denied;
	}
	public void setDenied(String denied) {
		Denied = denied;
	}
	

}
