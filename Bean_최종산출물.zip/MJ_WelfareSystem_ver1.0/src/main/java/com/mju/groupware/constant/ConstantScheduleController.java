package com.mju.groupware.constant;

public class ConstantScheduleController {

	private String UserId;
	private String SRole;
	private String PRole;
	private String ARole;
	
	private String Schedule;
	private String userID;
	private String scheduleID;
	private String start;
	private String end;
	
	public String getUserId() {
		return UserId;
	}
	public void setUserId(String userId) {
		UserId = userId;
	}
	public String getSRole() {
		return SRole;
	}
	public void setSRole(String sRole) {
		SRole = sRole;
	}
	public String getPRole() {
		return PRole;
	}
	public void setPRole(String pRole) {
		PRole = pRole;
	}
	public String getARole() {
		return ARole;
	}
	public void setARole(String aRole) {
		ARole = aRole;
	}
	public String getSchedule() {
		return Schedule;
	}
	public void setSchedule(String schedule) {
		Schedule = schedule;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getScheduleID() {
		return scheduleID;
	}
	public void setScheduleID(String scheduleID) {
		this.scheduleID = scheduleID;
	}
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public String getEnd() {
		return end;
	}
	public void setEnd(String end) {
		this.end = end;
	}
	

}
