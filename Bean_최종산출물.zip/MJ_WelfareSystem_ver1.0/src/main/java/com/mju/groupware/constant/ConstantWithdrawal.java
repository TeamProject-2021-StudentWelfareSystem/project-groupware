package com.mju.groupware.constant;

public class ConstantWithdrawal {

   private String Parameter1;
   private String Parameter2;
   private String Url;

   public String getUrl() {
      return Url;
   }

   public void setUrl(String url) {
      Url = url;
   }

   public String getParameter1() {
      return Parameter1;
   }

   public String getParameter2() {
      return Parameter2;
   }

   public void setParameter2(String parameter2) {
      Parameter2 = parameter2;
   }

   public void setParameter1(String parameter1) {
      Parameter1 = parameter1;
   }
   
}