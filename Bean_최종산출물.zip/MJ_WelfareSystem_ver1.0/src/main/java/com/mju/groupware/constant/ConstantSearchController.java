package com.mju.groupware.constant;

public class ConstantSearchController {

	private String SRole;
	private String PRole;
	private String ARole;
	private String UName;
	private String UserEmail;
	private String PhoneNum;
	
	private String RSearchUser;
	private String RReviewList;
	private String RRSearchUser;
	
	public String getPhoneNum() {
		return PhoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		PhoneNum = phoneNum;
	}
	public String getRSearchUser() {
		return RSearchUser;
	}
	public void setRSearchUser(String rSearchUser) {
		RSearchUser = rSearchUser;
	}
	public String getRReviewList() {
		return RReviewList;
	}
	public void setRReviewList(String rReviewList) {
		RReviewList = rReviewList;
	}
	public String getRRSearchUser() {
		return RRSearchUser;
	}
	public void setRRSearchUser(String rRSearchUser) {
		RRSearchUser = rRSearchUser;
	}
	public String getSRole() {
		return SRole;
	}
	public void setSRole(String sRole) {
		SRole = sRole;
	}
	public String getPRole() {
		return PRole;
	}
	public void setPRole(String pRole) {
		PRole = pRole;
	}
	public String getARole() {
		return ARole;
	}
	public void setARole(String aRole) {
		ARole = aRole;
	}
	
	public String getUName() {
		return UName;
	}
	public void setUName(String uName) {
		UName = uName;
	}
	public String getUserEmail() {
		return UserEmail;
	}
	public void setUserEmail(String userEmail) {
		UserEmail = userEmail;
	}
	

}
