
function setDisplay(){
  if($('input:radio[id=member_student]').is(':checked')){
      
      $('#teacher_signup').hide();
      $('#student_signup').show();
      $('#userLoginID').keypress(function (event) {
    	   if (event.which && (event.which <= 47 || event.which >= 58) && event.which != 8) {
    	      event.preventDefault(); 
    	    } 
    	    });
    		
  } else if($('input:radio[id=member_teacher]').is(':checked')){
      $('#student_signup').hide();
      $('#teacher_signup').show();
      $('#userLoginID1').keypress(function (event) {
    	   if (event.which && (event.which <= 47 || event.which >= 58) && event.which != 8) {
    	      event.preventDefault(); 
    	    } 
    	    });
    		
  }
  /*복수전공 있을 때만 드롭박스 보이게 하기*/
	if($('input:radio[id="member_DoubleMajor"]').is(':checked')){
			$('#studentDoubleMajor').show();
	} else{
			$('#studentDoubleMajor').hide();
	}
}

function studentLogin(){
  if($('#student_signup').show() && $('#teacher_signup').hide()){
    if($('#userLoginID').val().length==0 ||
      $('#userLoginPwd').val().length==0 ||
      $('#userName').val().length==0||
      $('#userPhoneNum').val().length==0||
      $('#studentGrade').val().length==0||
      $('#studentMajor').val().length==0||
      $('#userEmail').val().length==0||
      $('#studentGender').value==' '||
      $('#studentColleges').value==' '||
      $('#studentMajor').value==' '){
    alert("필수항목을 모두 입력해주세요.");
    return false;
    } else if($('#userLoginPwd').val().length<8){
      alert("비밀번호는 8자보다 많아야합니다.");
      return false;
    } else {
      alert("회원가입 성공!");
    }
  }
}

function teacherLogin(){
  if($('#teacher_signup').show() && $('#student_signup').hide()){
    if($('#userLoginID').val().length==0||
    $('#userLoginPwd').val().length==0 ||
     $('#userName').val().length==0||
     $('#student_gender').val().length==0||
     $('#userPhoneNum').val().length==0||
     $('#professorColleges').value==' '||
     $('#professorMajor').value==' '||
     $('#professorRoom').val().length==0||
     $('#userEmail').val().length==0){
       alert("필수항목을 모두 입력해주세요.");
       return false;
  } else if($('#userLoginPwd').val().length<8){
    alert("비밀번호는 8자보다 많아야합니다.");
    return false;
  } else {
    alert("회원가입 성공!");
  }
 
 }
}
	   
$(document).ready(function(){
		
	$('#SignupComplete').click(function(){
    if($('input:radio[id=member_student]').is(':checked')){
      studentLogin();
    }else if($('input:radio[id=member_teacher]').is(':checked')){
      teacherLogin();
    } 
    	    });
    		
  
	
	$('#userLoginID').keypress(function (event) {
    	   if (event.which && (event.which <= 47 || event.which >= 58) && event.which != 8) {
    	      event.preventDefault(); 
    	    } 
    	    });
	
    $('#email_check').click(function(){
      alert("메일 전송이 완료되었습니다.");
      $('#email_num').show();
	  $('#email_valid').show();
      const Mail = document.getElementById('email').value;
      var Domain = document.getElementById('mju').value;
      temp = Mail + Domain; // temp는 사용자가 입력한 메일주소 + 도메인입니다.
	
      setTimeout(function(){
        alert("인증 시간이 경과하였습니다.");
      }, 3000);
      return false;
    });
		$('#email_valid').click(function(){
			alert("인증번호가 일치하지 않습니다.");
			return false;
		})
});

