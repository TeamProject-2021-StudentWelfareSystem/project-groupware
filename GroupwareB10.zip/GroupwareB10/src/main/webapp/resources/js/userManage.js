$(document).ready(function(){ 
	$('#deleteBtn').click(function() {
		confirm('해당 회원을 삭제하시겠습니까?');
	}); 
});

