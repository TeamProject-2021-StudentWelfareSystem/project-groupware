package com.mju.groupware.dto;

public class ConstantAdminProfessorController {
	private String UserName;
	private String UserLoginID;
	private String UserPhoneNum;
	private String UserPhone;
	
	public String getUserPhone() {
		return UserPhone;
	}
	public void setUserPhone(String userPhone) {
		UserPhone = userPhone;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserLoginID() {
		return UserLoginID;
	}
	public void setUserLoginID(String userLoginID) {
		UserLoginID = userLoginID;
	}
	public String getUserPhoneNum() {
		return UserPhoneNum;
	}
	public void setUserPhoneNum(String userPhoneNum) {
		UserPhoneNum = userPhoneNum;
	}

}
