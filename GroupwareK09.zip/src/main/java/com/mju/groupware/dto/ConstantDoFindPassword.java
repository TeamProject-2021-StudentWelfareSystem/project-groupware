package com.mju.groupware.dto;

public class ConstantDoFindPassword {
	private String UName;
	private String Pwd;
	private String AuthNum;

	public String getAuthNum() {
		return AuthNum;
	}

	public void setAuthNum(String authNum) {
		AuthNum = authNum;
	}

	public String getPwd() {
		return Pwd;
	}

	public void setPwd(String pwd) {
		Pwd = pwd;
	}

	public String getUName() {
		return UName;
	}

	public void setUName(String uName) {
		UName = uName;
	}

}
