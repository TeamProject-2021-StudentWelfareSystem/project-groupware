package com.mju.groupware.dto;

public class ConstantAdminUserEmailDao {
	private String InsertCertification;
	private String SelectForCheckCertification;
	private String DeleteCertification;
	
	public String getInsertCertification() {
		return InsertCertification;
	}
	public void setInsertCertification(String insertCertification) {
		InsertCertification = insertCertification;
	}
	public String getSelectForCheckCertification() {
		return SelectForCheckCertification;
	}
	public void setSelectForCheckCertification(String selectForCheckCertification) {
		SelectForCheckCertification = selectForCheckCertification;
	}
	public String getDeleteCertification() {
		return DeleteCertification;
	}
	public void setDeleteCertification(String deleteCertification) {
		DeleteCertification = deleteCertification;
	}
	
}
