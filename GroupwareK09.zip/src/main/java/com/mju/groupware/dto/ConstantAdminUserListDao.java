package com.mju.groupware.dto;

public class ConstantAdminUserListDao {
	private String UserListDaoID;
	private String SelectUserList;
	private String SelectDormantList;
	private String SelectWithdrawalList;
	private String SelectWithdrawalUserListForRecovery;
	private String SelectWithdrawalStudentListForRecovery;
	private String SelectWithdrawalProfessorListForRecovery;
	private String InsertUserForRecovery;
	private String InsertStudentForRecovery;
	private String InsertProfessorForRecovery;
	
	public String getUserListDaoID() {
		return UserListDaoID;
	}
	public void setUserListDaoID(String userListDaoID) {
		UserListDaoID = userListDaoID;
	}
	public String getSelectUserList() {
		return SelectUserList;
	}
	public void setSelectUserList(String selectUserList) {
		SelectUserList = selectUserList;
	}
	public String getSelectDormantList() {
		return SelectDormantList;
	}
	public void setSelectDormantList(String selectDormantList) {
		SelectDormantList = selectDormantList;
	}
	public String getSelectWithdrawalList() {
		return SelectWithdrawalList;
	}
	public void setSelectWithdrawalList(String selectWithdrawalList) {
		SelectWithdrawalList = selectWithdrawalList;
	}
	public String getSelectWithdrawalUserListForRecovery() {
		return SelectWithdrawalUserListForRecovery;
	}
	public void setSelectWithdrawalUserListForRecovery(String selectWithdrawalUserListForRecovery) {
		SelectWithdrawalUserListForRecovery = selectWithdrawalUserListForRecovery;
	}
	public String getSelectWithdrawalStudentListForRecovery() {
		return SelectWithdrawalStudentListForRecovery;
	}
	public void setSelectWithdrawalStudentListForRecovery(String selectWithdrawalStudentListForRecovery) {
		SelectWithdrawalStudentListForRecovery = selectWithdrawalStudentListForRecovery;
	}
	public String getSelectWithdrawalProfessorListForRecovery() {
		return SelectWithdrawalProfessorListForRecovery;
	}
	public void setSelectWithdrawalProfessorListForRecovery(String selectWithdrawalProfessorListForRecovery) {
		SelectWithdrawalProfessorListForRecovery = selectWithdrawalProfessorListForRecovery;
	}
	public String getInsertUserForRecovery() {
		return InsertUserForRecovery;
	}
	public void setInsertUserForRecovery(String insertUserForRecovery) {
		InsertUserForRecovery = insertUserForRecovery;
	}
	public String getInsertStudentForRecovery() {
		return InsertStudentForRecovery;
	}
	public void setInsertStudentForRecovery(String insertStudentForRecovery) {
		InsertStudentForRecovery = insertStudentForRecovery;
	}
	public String getInsertProfessorForRecovery() {
		return InsertProfessorForRecovery;
	}
	public void setInsertProfessorForRecovery(String insertProfessorForRecovery) {
		InsertProfessorForRecovery = insertProfessorForRecovery;
	}
	
}
