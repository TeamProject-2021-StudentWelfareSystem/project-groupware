package com.mju.groupware.dto;

public class ConstantAdminStudentController {
	private String UserName;
	private String UserLoginID;
	private String UserPhoneNum;
	private String UserPhone;
	private String UserEmail;
	private String UserGrade;
	private String UserMajor;
	private String UserNameForOpen;

	public String getUserNameForOpen() {
		return UserNameForOpen;
	}

	public void setUserNameForOpen(String userNameForOpen) {
		UserNameForOpen = userNameForOpen;
	}

	public String getUserEmail() {
		return UserEmail;
	}

	public void setUserEmail(String userEmail) {
		UserEmail = userEmail;
	}

	public String getUserGrade() {
		return UserGrade;
	}

	public void setUserGrade(String userGrade) {
		UserGrade = userGrade;
	}

	public String getUserMajor() {
		return UserMajor;
	}

	public void setUserMajor(String userMajor) {
		UserMajor = userMajor;
	}

	public String getUserPhone() {
		return UserPhone;
	}

	public void setUserPhone(String userPhone) {
		UserPhone = userPhone;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getUserLoginID() {
		return UserLoginID;
	}

	public void setUserLoginID(String userLoginID) {
		UserLoginID = userLoginID;
	}

	public String getUserPhoneNum() {
		return UserPhoneNum;
	}

	public void setUserPhoneNum(String userPhoneNum) {
		UserPhoneNum = userPhoneNum;
	}

}