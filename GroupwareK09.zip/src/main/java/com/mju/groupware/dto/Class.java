package com.mju.groupware.dto;

public class Class {
	private int ClassID;
	private String ClassName;
	private String ClassType;
	private String ClassProfessorName;
	
	public int getClassID() {
		return ClassID;
	}
	public void setClassID(int classID) {
		ClassID = classID;
	}
	public String getClassName() {
		return ClassName;
	}
	public void setClassName(String className) {
		ClassName = className;
	}
	public String getClassType() {
		return ClassType;
	}
	public void setClassType(String classType) {
		ClassType = classType;
	}
	public String getClassProfessorName() {
		return ClassProfessorName;
	}
	public void setClassProfessorName(String classProfessorName) {
		ClassProfessorName = classProfessorName;
	}

}
