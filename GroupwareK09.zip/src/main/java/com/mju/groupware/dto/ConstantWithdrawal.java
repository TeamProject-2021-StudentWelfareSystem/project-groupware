package com.mju.groupware.dto;

public class ConstantWithdrawal {

	private String Parameter1;
	private String Parameter2;
	private String Parameter3;
	private String Url;

	public String getUrl() {
		return Url;
	}

	public void setUrl(String url) {
		Url = url;
	}

	public String getParameter3() {
		return Parameter3;
	}

	public void setParameter3(String parameter3) {
		Parameter3 = parameter3;
	}

	public String getParameter1() {
		return Parameter1;
	}

	public String getParameter2() {
		return Parameter2;
	}

	public void setParameter2(String parameter2) {
		Parameter2 = parameter2;
	}

	public void setParameter1(String parameter1) {
		Parameter1 = parameter1;
	}
}
