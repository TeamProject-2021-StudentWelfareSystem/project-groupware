package com.mju.groupware.dto;

public class ConstantAdminOpenInfoDao {
	
	private String SelectForOpenInfoAll;

	public String getSelectForOpenInfoAll() {
		return SelectForOpenInfoAll;
	}

	public void setSelectForOpenInfoAll(String selectForOpenInfoAll) {
		SelectForOpenInfoAll = selectForOpenInfoAll;
	}
	
}
