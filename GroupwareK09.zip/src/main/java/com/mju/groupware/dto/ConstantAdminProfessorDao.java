package com.mju.groupware.dto;

public class ConstantAdminProfessorDao {
	private String InsertInformationP;
	private String UpdateUserID;
	private String UpdateProfessorRoom;
	private String UpdateProfessorRoomNum;
	private String SelectProfessorProfileInfo;
	private String SelectMyPageProfessorInfo;
	private String SelectMyPageProfessorInfoByID;
	private String UpdateProfessorColleges;
	private String UpdateProfessorMajor;
	private String SelectProfessorInfo;
	private String InsertWithdrawalProfessor;
	private String DeleteWithdrawalProfessor;
	private String DeleteWithdrawalProfessorList;
	
	public String getUpdateUserID() {
		return UpdateUserID;
	}

	public void setUpdateUserID(String updateUserID) {
		UpdateUserID = updateUserID;
	}

	public String getUpdateProfessorRoom() {
		return UpdateProfessorRoom;
	}

	public void setUpdateProfessorRoom(String updateProfessorGender) {
		UpdateProfessorRoom = updateProfessorGender;
	}

	public String getUpdateProfessorRoomNum() {
		return UpdateProfessorRoomNum;
	}

	public void setUpdateProfessorRoomNum(String updateProfessorGrade) {
		UpdateProfessorRoomNum = updateProfessorGrade;
	}

	public String getSelectProfessorProfileInfo() {
		return SelectProfessorProfileInfo;
	}

	public void setSelectProfessorProfileInfo(String selectProfessorProfileInfo) {
		SelectProfessorProfileInfo = selectProfessorProfileInfo;
	}

	public String getSelectMyPageProfessorInfo() {
		return SelectMyPageProfessorInfo;
	}

	public void setSelectMyPageProfessorInfo(String selectMyPageProfessorInfo) {
		SelectMyPageProfessorInfo = selectMyPageProfessorInfo;
	}

	public String getSelectMyPageProfessorInfoByID() {
		return SelectMyPageProfessorInfoByID;
	}

	public void setSelectMyPageProfessorInfoByID(String selectMyPageProfessorInfoByID) {
		SelectMyPageProfessorInfoByID = selectMyPageProfessorInfoByID;
	}

	public String getUpdateProfessorColleges() {
		return UpdateProfessorColleges;
	}

	public void setUpdateProfessorColleges(String updateProfessorColleges) {
		UpdateProfessorColleges = updateProfessorColleges;
	}

	public String getUpdateProfessorMajor() {
		return UpdateProfessorMajor;
	}

	public void setUpdateProfessorMajor(String updateProfessorMajor) {
		UpdateProfessorMajor = updateProfessorMajor;
	}

	public String getSelectProfessorInfo() {
		return SelectProfessorInfo;
	}

	public void setSelectProfessorInfo(String selectProfessorInfo) {
		SelectProfessorInfo = selectProfessorInfo;
	}

	public String getInsertWithdrawalProfessor() {
		return InsertWithdrawalProfessor;
	}

	public void setInsertWithdrawalProfessor(String insertWithdrawalProfessor) {
		InsertWithdrawalProfessor = insertWithdrawalProfessor;
	}

	public String getDeleteWithdrawalProfessor() {
		return DeleteWithdrawalProfessor;
	}

	public void setDeleteWithdrawalProfessor(String deleteWithdrawalProfessor) {
		DeleteWithdrawalProfessor = deleteWithdrawalProfessor;
	}

	public String getDeleteWithdrawalProfessorList() {
		return DeleteWithdrawalProfessorList;
	}

	public void setDeleteWithdrawalProfessorList(String deleteWithdrawalProfessorList) {
		DeleteWithdrawalProfessorList = deleteWithdrawalProfessorList;
	}

	public String getInsertInformation() {
		return InsertInformationP;
	}

	public void setInsertInformation(String insertInformation) {
		InsertInformationP = insertInformation;
	}
	
}
